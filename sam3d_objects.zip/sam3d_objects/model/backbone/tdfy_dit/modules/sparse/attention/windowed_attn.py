# Copyright (c) Meta Platforms, Inc. and affiliates.
from typing import *
import torch
import math
from .. import SparseTensor
from .. import DEBUG, ATTN

from torch.nn.functional import scaled_dot_product_attention as sdpa
from .masked_sdpa import masked_sdpa


__all__ = [
    "sparse_windowed_scaled_dot_product_self_attention",
]


def calc_window_partition(
    tensor: SparseTensor,
    window_size: Union[int, Tuple[int, ...]],
    shift_window: Union[int, Tuple[int, ...]] = 0,
) -> Tuple[torch.Tensor, torch.Tensor, List[int], List[int]]:
    """
    Calculate serialization and partitioning for a set of coordinates.

    Args:
        tensor (SparseTensor): The input tensor.
        window_size (int): The window size to use.
        shift_window (Tuple[int, ...]): The shift of serialized coordinates.

    Returns:
        (torch.Tensor): Forwards indices.
        (torch.Tensor): Backwards indices.
        (List[int]): Sequence lengths.
        (List[int]): Sequence batch indices.
    """
    DIM = tensor.coords.shape[1] - 1
    shift_window = (
        (shift_window,) * DIM if isinstance(shift_window, int) else shift_window
    )
    window_size = (window_size,) * DIM if isinstance(window_size, int) else window_size
    shifted_coords = tensor.coords.clone().detach()
    shifted_coords[:, 1:] += torch.tensor(
        shift_window, device=shifted_coords.device, dtype=torch.int32
    ).unsqueeze(0)

    MAX_COORDS = shifted_coords[:, 1:].max(dim=0).values.tolist()
    NUM_WINDOWS = [math.ceil((mc + 1) / ws) for mc, ws in zip(MAX_COORDS, window_size)]
    OFFSET = torch.cumprod(torch.tensor([1] + NUM_WINDOWS[::-1], device=shifted_coords.device), dim=0).tolist()[::-1]

    shifted_coords[:, 1:] //= torch.tensor(
        window_size, device=shifted_coords.device, dtype=torch.int32
    ).unsqueeze(0)
    shifted_indices = (
        shifted_coords
        * torch.tensor(OFFSET, device=shifted_coords.device, dtype=shifted_coords.dtype).unsqueeze(0)
    ).sum(dim=1)
    fwd_indices = torch.argsort(shifted_indices)
    bwd_indices = torch.empty_like(fwd_indices)
    bwd_indices[fwd_indices] = torch.arange(fwd_indices.shape[0], device=fwd_indices.device)
    seq_lens = torch.bincount(shifted_indices)
    seq_batch_indices = (
        torch.arange(seq_lens.shape[0], device=seq_lens.device, dtype=torch.int32)
        // OFFSET[0]
    )
    mask = seq_lens != 0
    seq_lens = seq_lens[mask].tolist()
    seq_batch_indices = seq_batch_indices[mask].tolist()

    return fwd_indices, bwd_indices, seq_lens, seq_batch_indices


import time

# Timing stats for windowed attention
_windowed_attn_timing = {"partition": 0.0, "attn": 0.0, "count": 0}

def sparse_windowed_scaled_dot_product_self_attention(
    qkv: SparseTensor, window_size: int, shift_window: Tuple[int, int, int] = (0, 0, 0)
) -> SparseTensor:
    """
    Apply windowed scaled dot product self attention to a sparse tensor.

    Args:
        qkv (SparseTensor): [N, *, 3, H, C] sparse tensor containing Qs, Ks, and Vs.
        window_size (int): The window size to use.
        shift_window (Tuple[int, int, int]): The shift of serialized coordinates.
        shift (int): The shift to use.
    """
    assert (
        len(qkv.shape) == 4 and qkv.shape[1] == 3
    ), f"Invalid shape for qkv, got {qkv.shape}, expected [N, *, 3, H, C]"

    serialization_spatial_cache_name = f"window_partition_{window_size}_{shift_window}"
    serialization_spatial_cache = qkv.get_spatial_cache(
        serialization_spatial_cache_name
    )
    if serialization_spatial_cache is None:
        fwd_indices, bwd_indices, seq_lens, seq_batch_indices = calc_window_partition(
            qkv, window_size, shift_window
        )
        qkv.register_spatial_cache(
            serialization_spatial_cache_name,
            (fwd_indices, bwd_indices, seq_lens, seq_batch_indices),
        )
    else:
        fwd_indices, bwd_indices, seq_lens, seq_batch_indices = (
            serialization_spatial_cache
        )

    M = fwd_indices.shape[0]
    T = qkv.feats.shape[0]
    H = qkv.feats.shape[2]
    C = qkv.feats.shape[3]

    # Ensure indices are on same device as features for indexing
    if fwd_indices.device != qkv.feats.device:
        fwd_indices = fwd_indices.to(qkv.feats.device)
        bwd_indices = bwd_indices.to(qkv.feats.device)
    qkv_feats = qkv.feats[fwd_indices]  # [M, 3, H, C]

    if DEBUG:
        start = 0
        qkv_coords = qkv.coords[fwd_indices]
        for i in range(len(seq_lens)):
            seq_coords = qkv_coords[start : start + seq_lens[i]]
            assert (
                seq_coords[:, 0] == seq_batch_indices[i]
            ).all(), (
                f"SparseWindowedScaledDotProductSelfAttention: batch index mismatch"
            )
            assert (
                seq_coords[:, 1:].max(dim=0).values
                - seq_coords[:, 1:].min(dim=0).values
                < window_size
            ).all(), (
                f"SparseWindowedScaledDotProductSelfAttention: window size exceeded"
            )
            start += seq_lens[i]

    if all([seq_len == window_size for seq_len in seq_lens]):
        B = len(seq_lens)
        N = window_size
        qkv_feats = qkv_feats.reshape(B, N, 3, H, C)
        q, k, v = qkv_feats.unbind(dim=2)
        q = q.permute(0, 2, 1, 3)  # [N, H, L, C]
        k = k.permute(0, 2, 1, 3)  # [N, H, L, C]
        v = v.permute(0, 2, 1, 3)  # [N, H, L, C]
        out = sdpa(q, k, v)  # [N, H, L, C]
        out = out.permute(0, 2, 1, 3)  # [N, L, H, C]
        out = out.reshape(B * N, H, C)  # [M, H, C]
    else:
        q, k, v = qkv_feats.unbind(dim=1)
        q = q.unsqueeze(0)
        k = k.unsqueeze(0)
        v = v.unsqueeze(0)
        out = masked_sdpa(q, k, v, seq_lens, seq_lens)

    # Ensure bwd_indices is on same device as out for indexing
    if bwd_indices.device != out.device:
        bwd_indices = bwd_indices.to(out.device)
    out = out[bwd_indices]  # [T, H, C]

    if DEBUG:
        qkv_coords = qkv_coords[bwd_indices]
        assert torch.equal(
            qkv_coords, qkv.coords
        ), "SparseWindowedScaledDotProductSelfAttention: coordinate mismatch"

    return qkv.replace(out)
